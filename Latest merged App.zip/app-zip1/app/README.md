Mealer App Project for SEG 2105 <br>
Saad Mazhar - 300249820 <br>
Obay Alshaer - 300170489<br>
Bassel Nawfal - 300188651 <br>
Abeed Zaman - 300234175 <br>
<img width="207" alt="image" src="https://user-images.githubusercontent.com/42980243/197291486-34243e8e-6307-42f8-ad39-63cd3a8b5ca9.png">
<br>logins for admin class
