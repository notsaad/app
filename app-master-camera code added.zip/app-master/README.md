Mealer App Project for SEG 2105 <br>
Saad Mazhar - 300249820 <br>
Obay Alshaer - <br>
Bassel Nawfal - 300188651 <br>
Abeed - <br>
