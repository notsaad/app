package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class Menu extends AppCompatActivity {

    ListView listView;
    ArrayList<String> listMenuItem = new ArrayList<String>();
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DBHelper DB = new DBHelper(this);


        viewData();

        setContentView(R.layout.activity_complaint_list);
        listView = (ListView) findViewById(R.id.customListView);
        String[] arrMenuItem = new String[listMenuItem.size()];
        arrMenuItem = listMenuItem.toArray(arrMenuItem);

        System.out.println(Arrays.toString(arrMenuItem));
        CustomBaseAdapter customBaseAdapter = new CustomBaseAdapter(getApplicationContext(),arrMenuItem);
        listView.setAdapter(customBaseAdapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                new AlertDialog.Builder(Menu.this)
                        .setTitle("Do you want to remove from list?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                DB.deleteData(String.valueOf(position));
                                customBaseAdapter.notifyDataSetChanged();
                            }

                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).create().show();
            }
        });
    }

    private void viewData(){
        Cursor res = db.viewMenuData();
        while(res.moveToNext()){
            listMenuItem.add(res.getString(0));
        }
    }



}