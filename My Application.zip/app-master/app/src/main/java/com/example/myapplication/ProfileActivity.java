package com.example.myapplication;

import static com.example.myapplication.R.id.name_text_view;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.time.Instant;
import java.time.temporal.TemporalAdjuster;

public class ProfileActivity<RatingCallback, User> extends AppCompatActivity {

    private TextView mNameTextView;
    private ImageView mProfileImageView;
    private RatingBar mRatingBar;
    private Instant Glide;
    private Bundle savedInstanceState;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mNameTextView = findViewById(name_text_view);
        mProfileImageView = findViewById(R.id.profile_image_view);
        mRatingBar = findViewById(R.id.rating_bar);

        mNameTextView.setText(getCurrentUser().getUser());
        Glide.with((TemporalAdjuster) this)
                .load(getCurrentUser().getProfileImageUrl())
                .into(mProfileImageView);

        getUserRating(new RatingCallback() {
            public void onRatingReceived(float rating) {
                mRatingBar.setRating(rating);
            }
        });
    }

    private User getCurrentUser() {
        // TODO: Return the currently logged-in user
    }

    private void getUserRating(RatingCallback callback) {
        // TODO: Query the database or API for the user's rating and invoke the callback with the rating value
    }
}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        this.savedInstanceState = savedInstanceState;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}