package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MealSearch extends AppCompatActivity {
    public static void main(String[] args) {
        String searchQuery;


        Scanner input = new Scanner(System.in);


        System.out.println("Enter your search query: ");

        searchQuery = input.nextLine();

        List<String> results = search(searchQuery);

        for (String meal : results) {
            System.out.println(meal);
        }
    }

    // Define the search method
    public static List<String> search(String query) {
        // This is where you would implement the logic for searching for meals
        // based on the user's input. For now, we will just return a dummy list
        // of meals.
        List<String> meals = new ArrayList<String>();
        meals.add("Spaghetti Bolognese");
        meals.add("Chicken Parmesan");
        meals.add("Vegetable Stir Fry");
        return meals;
    }


    @Override
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
    private PurchasesUpdatedListener purchasesUpdatedListener = new PurchasesUpdatedListener() {
        @Override
        public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {

        }
    };

    private Context context;
    private BillingClient billingClient = BillingClient.newBuilder(context)
            .setListener(purchasesUpdatedListener)
            .enablePendingPurchases()
            .build();
    private BillingResult billingResult = this.billingClient;
    BillingClient.startConnection(new void BillingClientStateListener() {
        @Override
        public void onBillingSetupFinished(BillingResult ) {}
            if (billingResult.getResponseCode() ==  BillingClient.BillingResponseCode.OK) {

            }

    };

    void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK
                && purchases != null) {
            for (Purchase purchase : purchases) {
                handlePurchase(purchase);
            }
        } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
        } else {

        }
    }

    private void handlePurchase(Purchase purchase) {
    }

}